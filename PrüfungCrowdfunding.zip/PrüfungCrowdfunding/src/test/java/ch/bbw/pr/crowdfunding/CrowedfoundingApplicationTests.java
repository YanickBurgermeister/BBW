package ch.bbw.pr.crowdfunding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrowedfoundingApplicationTests {

	@Test
	void contextLoads() {
	}

}
