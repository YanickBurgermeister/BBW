package ch.bbw.yb.autohaus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoHausApplicationTests {

    @Test
    void contextLoads() {
    }

}
